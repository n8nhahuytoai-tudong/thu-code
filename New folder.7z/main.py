# main.py
import sys
from modules.app_runner import run

if __name__ == "__main__":
    sys.exit(run())